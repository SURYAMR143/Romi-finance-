
            function daskbar_open(){
                document.getElementById("dashboard").innerHTML="<div class='dash-top'><div class='logo'><img src='logo.png'>Romi.Finance</div><button id='close-btn' onclick='daskbar_close()'>X</button></div><menu><ul><li><a href='#'>Home</a></li><li><a href='#'>Dashboard</a></li><li>NFT</li><ul><li>Mint</li><li>Stack NFT</li></ul><li>Earn</li><li>Buy</li><li>Referrals</li><li>EcoSystem</li><li>About</li><li>Settings</li></ul></menu>";
            }

            function daskbar_close(){
                
            }